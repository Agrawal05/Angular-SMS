import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddStudentComponent } from './add-student/add-student.component';
import { EditStudentComponent } from './edit-student/edit-student.component';
import { GetStudentComponent } from './get-student/get-student.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';

export const routes: Routes = [
  {path:'', redirectTo: 'Header', pathMatch:"full"},
  {path: 'Home', component:HomeComponent},
  { path: 'AddStudent',  component:AddStudentComponent },
  { path: 'GetStudents',  component:GetStudentComponent },
  { path: 'UpdateStudent',  component:EditStudentComponent },
  { path: 'Header', component:HeaderComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
