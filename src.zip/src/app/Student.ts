export class Student{
    public id: number;
    public studentname: String;
    public course: String;
    public fee: number;
}