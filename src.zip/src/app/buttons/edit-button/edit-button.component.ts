import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-edit-button',
  templateUrl: './edit-button.component.html',
  styleUrls: ['./edit-button.component.css']
})
export class EditButtonComponent implements OnInit {
@Input() BtnName1: string='';
@Output() BtnClick = new EventEmitter<string>();
  constructor() { }

  ngOnInit(): void {
  }

  EditEmitEvent(){
    this.BtnClick.emit();
  }
}