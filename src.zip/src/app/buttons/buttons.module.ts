import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddButtonComponent } from './add-button/add-button.component';
import { EditButtonComponent } from './edit-button/edit-button.component';
import { DeleteButtonComponent } from './delete-button/delete-button.component';



@NgModule({
  declarations: [AddButtonComponent, EditButtonComponent, DeleteButtonComponent],
  imports: [
    CommonModule
  ]
})
export class ButtonsModule { }
